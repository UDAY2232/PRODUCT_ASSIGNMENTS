package com.example.hotel;

import java.util.ArrayList;

public class Hotel {
    private ArrayList<Room> rooms;
    private ArrayList<Booking> bookings;
    private int nextBookingId;

    public Hotel() {
        rooms = new ArrayList<>();
        bookings = new ArrayList<>();
        nextBookingId = 1;
        addDefaultRooms();
    }

    private void addDefaultRooms() {
        rooms.add(new Room(101, "Single", 1000));
        rooms.add(new Room(102, "Double", 1500));
        rooms.add(new Room(103, "Deluxe", 2500));
    }

    public void displayAvailableRooms() {
        boolean hasAvailableRoom = false;
        System.out.println("\nAvailable Rooms:");

        for (Room room : rooms) {
            if (room.isAvailable()) {
                System.out.printf("Room %d - %s - Rs. %.2f per day%n",
                        room.getRoomNumber(), room.getRoomType(), room.getPrice());
                hasAvailableRoom = true;
            }
        }

        if (!hasAvailableRoom) {
            System.out.println("No rooms are currently available.");
        }
    }

    public Booking bookRoom(String customerName, int roomNumber, int numberOfDays) {
        if (customerName == null || customerName.trim().isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be empty.");
        }
        if (numberOfDays <= 0) {
            throw new IllegalArgumentException("Number of days must be greater than zero.");
        }

        Room room = findRoom(roomNumber);
        if (room == null) {
            throw new IllegalArgumentException("Invalid room number.");
        }
        if (!room.isAvailable()) {
            throw new IllegalArgumentException("This room is already booked.");
        }

        Booking booking = new Booking(nextBookingId++, customerName.trim(), roomNumber, numberOfDays);
        bookings.add(booking);
        room.setAvailable(false);
        return booking;
    }

    public void displayBookings() {
        if (bookings.isEmpty()) {
            System.out.println("\nNo bookings found.");
            return;
        }

        System.out.println("\nBookings:");
        for (Booking booking : bookings) {
            Room room = findRoom(booking.getRoomNumber());
            double totalAmount = room.getPrice() * booking.getNumberOfDays();
            System.out.printf("Booking ID: %d | Customer: %s | Room: %d | Days: %d | Total: Rs. %.2f%n",
                    booking.getBookingId(), booking.getCustomerName(), booking.getRoomNumber(),
                    booking.getNumberOfDays(), totalAmount);
        }
    }

    public boolean cancelBooking(int bookingId) {
        Booking booking = findBooking(bookingId);
        if (booking == null) {
            return false;
        }

        bookings.remove(booking);
        Room room = findRoom(booking.getRoomNumber());
        room.setAvailable(true);
        return true;
    }

    public double calculateTotalAmount(Booking booking) {
        Room room = findRoom(booking.getRoomNumber());
        return room.getPrice() * booking.getNumberOfDays();
    }

    private Room findRoom(int roomNumber) {
        for (Room room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                return room;
            }
        }
        return null;
    }

    private Booking findBooking(int bookingId) {
        for (Booking booking : bookings) {
            if (booking.getBookingId() == bookingId) {
                return booking;
            }
        }
        return null;
    }
}
