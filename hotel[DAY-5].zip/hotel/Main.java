package com.example.hotel;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            displayMenu();
            int choice = readInt(scanner, "Enter choice: ");

            switch (choice) {
                case 1:
                    hotel.displayAvailableRooms();
                    break;
                case 2:
                    bookRoom(scanner, hotel);
                    break;
                case 3:
                    hotel.displayBookings();
                    break;
                case 4:
                    cancelBooking(scanner, hotel);
                    break;
                case 5:
                    running = false;
                    System.out.println("Thank you for using the Hotel Booking System.");
                    break;
                default:
                    System.out.println("Invalid menu choice. Please select 1 to 5.");
            }
        }

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("\n===== HOTEL BOOKING SYSTEM =====");
        System.out.println("1. View Available Rooms");
        System.out.println("2. Book Room");
        System.out.println("3. View Bookings");
        System.out.println("4. Cancel Booking");
        System.out.println("5. Exit");
    }

    private static void bookRoom(Scanner scanner, Hotel hotel) {
        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine().trim();
        int roomNumber = readInt(scanner, "Enter room number: ");
        int numberOfDays = readInt(scanner, "Enter number of days: ");

        try {
            Booking booking = hotel.bookRoom(customerName, roomNumber, numberOfDays);
            System.out.println("Booking successful!");
            System.out.println("Booking ID: " + booking.getBookingId());
            System.out.printf("Total Amount: Rs. %.2f%n", hotel.calculateTotalAmount(booking));
        } catch (IllegalArgumentException exception) {
            System.out.println("Booking failed: " + exception.getMessage());
        }
    }

    private static void cancelBooking(Scanner scanner, Hotel hotel) {
        int bookingId = readInt(scanner, "Enter booking ID: ");
        if (hotel.cancelBooking(bookingId)) {
            System.out.println("Booking cancelled successfully.");
            System.out.println("The room is now available.");
        } else {
            System.out.println("Invalid booking ID. No booking was cancelled.");
        }
    }

    private static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int value = Integer.parseInt(scanner.nextLine().trim());
                return value;
            } catch (NumberFormatException exception) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

}
