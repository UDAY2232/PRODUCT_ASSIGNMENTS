package com.example.hotel;

public class Booking {
    private int bookingId;
    private String customerName;
    private int roomNumber;
    private int numberOfDays;

    public Booking(int bookingId, String customerName, int roomNumber, int numberOfDays) {
        this.bookingId = bookingId;
        this.customerName = customerName;
        this.roomNumber = roomNumber;
        this.numberOfDays = numberOfDays;
    }

    public int getBookingId() {
        return bookingId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public int getNumberOfDays() {
        return numberOfDays;
    }
}
