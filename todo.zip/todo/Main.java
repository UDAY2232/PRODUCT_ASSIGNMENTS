package com.example.todo;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static TodoList todoList = new TodoList();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            printMenu();
            int choice = readInt("Enter choice: ");
            switch (choice) {
                case 1:
                    handleAdd();
                    break;
                case 2:
                    handleView();
                    break;
                case 3:
                    handleUpdate();
                    break;
                case 4:
                    handleDelete();
                    break;
                case 5:
                    handleMarkCompleted();
                    break;
                case 6:
                    System.out.println("Exiting. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
            System.out.println();
        }
    }

    private static void printMenu() {
        System.out.println("===== TODO LIST =====");
        System.out.println("1. Add Task");
        System.out.println("2. View Tasks");
        System.out.println("3. Update Task");
        System.out.println("4. Delete Task");
        System.out.println("5. Mark Task Completed");
        System.out.println("6. Exit");
    }

    private static int readInt(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            scanner.nextLine();
            System.out.print("Please enter a number: ");
        }
        int val = scanner.nextInt();
        scanner.nextLine();
        return val;
    }

    private static void handleAdd() {
        System.out.print("Title: ");
        String title = scanner.nextLine();
        System.out.print("Description: ");
        String desc = scanner.nextLine();
        Task t = todoList.addTask(title, desc);
        System.out.println("Added: " + t);
    }

    private static void handleView() {
        List<Task> tasks = todoList.getAllTasks();
        if (tasks.isEmpty()) {
            System.out.println("No tasks.");
            return;
        }
        for (Task t : tasks) {
            System.out.println(t);
        }
    }

    private static void handleUpdate() {
        int id = readInt("Enter task id to update: ");
        Task t = todoList.findById(id);
        if (t == null) {
            System.out.println("Task not found.");
            return;
        }
        System.out.print("New title (leave blank to keep): ");
        String title = scanner.nextLine();
        System.out.print("New description (leave blank to keep): ");
        String desc = scanner.nextLine();
        String newTitle = title.isEmpty() ? t.getTitle() : title;
        String newDesc = desc.isEmpty() ? t.getDescription() : desc;
        boolean ok = todoList.updateTask(id, newTitle, newDesc);
        System.out.println(ok ? "Updated." : "Update failed.");
    }

    private static void handleDelete() {
        int id = readInt("Enter task id to delete: ");
        boolean ok = todoList.deleteTask(id);
        System.out.println(ok ? "Deleted." : "Task not found.");
    }

    private static void handleMarkCompleted() {
        int id = readInt("Enter task id to mark completed: ");
        boolean ok = todoList.markCompleted(id);
        System.out.println(ok ? "Marked completed." : "Task not found.");
    }
}
