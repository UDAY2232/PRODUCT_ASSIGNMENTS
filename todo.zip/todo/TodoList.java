package com.example.todo;

import java.util.ArrayList;
import java.util.List;

public class TodoList {
    private List<Task> tasks;
    private int nextId;

    public TodoList() {
        tasks = new ArrayList<>();
        nextId = 1;
    }

    public Task addTask(String title, String description) {
        Task t = new Task(nextId++, title, description);
        tasks.add(t);
        return t;
    }

    public List<Task> getAllTasks() {
        return new ArrayList<>(tasks);
    }

    public Task findById(int id) {
        for (Task t : tasks) {
            if (t.getId() == id) return t;
        }
        return null;
    }

    public boolean updateTask(int id, String newTitle, String newDescription) {
        Task t = findById(id);
        if (t == null) return false;
        t.setTitle(newTitle);
        t.setDescription(newDescription);
        return true;
    }

    public boolean deleteTask(int id) {
        Task t = findById(id);
        if (t == null) return false;
        return tasks.remove(t);
    }

    public boolean markCompleted(int id) {
        Task t = findById(id);
        if (t == null) return false;
        t.setCompleted(true);
        return true;
    }
}
